# File Index

This index describes the files present in this archive. Nested archives and media should be reviewed separately for privacy and provenance.

## Main documentation
- `ANONYMOUS_Temporal_GIS_Proposal_for_Backward_Time_Travel_Safety.md`
- `ARCHIVE_OVERVIEW.md`
- `EMPORAL_GIS_MISSION_CLARIFICATION_AND_SAFETY_REQUIREMENTS.md`
- `FUTURE_RESEARCH_DIRECTIVE.md`
- `ISS_Temporal_Research_Protocol.md`
- `OCT_16_2026_01-00_AM_EDT_MISSION.md`
- `README.md`
- `SCIENTIFIC_CORRECTIONS_AND_LIMITATIONS.md`
- `Time Travel Beacon.md`
- `WARP_BUBBLE_HUMAN_TRANSPORT_AND_PHYSICS_CONSTRAINTS.md`
- `bootstrap.py`
- `legacy_invalid_schema_original.txt`
- `legacy_mixed_code_and_notes.txt`
- `legacy_mixed_markdown_python.txt`
- `quantum-resonance-calibration-protocols.txt`
- `temporal_mission_schema.json`
- `temporal_receiver_simulation.py`

## PDFs
- `Regulating Backwards Time Travel (And Temporal GIS Technology) - Man Made Laws.pdf`
- `The Right Way To Backwards Time Travel.pdf`
- `Time Travel Mission Instructions.pdf`
- `Why Is My Do-Over What's Best For Everyone_.pdf`
- `Why backwards time travel is possible.pdf`

## Images
- `IMG_0235.png`
- `IMG_0236.png`
- `IMG_0237.png`
- `IMG_0238.png`
- `IMG_0239.png`
- `IMG_0240.png`
- `IMG_0241.png`
- `IMG_0242.png`
- `IMG_0243.png`
- `IMG_0244.png`
- `IMG_0245.png`
- `IMG_0246.png`
- `IMG_0247.png`

## Nested ZIP archives
- `Backwards Time Travel Mission-20261011T235200Z-1-001.zip` - historical archive; inspect contents before public sharing.
- `Backwards Time Travel Mission-20261016T024737Z-1-001.zip` - historical archive; inspect contents before public sharing.
- `Backwards Time Travel UNLOCKED-20261016T024746Z-1-001.zip` - historical archive; inspect contents before public sharing.
- `drive-download-20261012T203346Z-1-001.zip` - historical archive; inspect contents before public sharing.
- `drive-download-20261012T210944Z-1-001.zip` - historical archive; inspect contents before public sharing.
- `drive-download-20261012T210946Z-1-001.zip` - historical archive; inspect contents before public sharing.
- `drive-download-20261012T211030Z-1-001.zip` - historical archive; inspect contents before public sharing.
- `drive-download-20261012T211101Z-1-001.zip` - historical archive; inspect contents before public sharing.
- `drive-download-20261012T211129Z-1-001.zip` - historical archive; inspect contents before public sharing.
- `drive-download-20261012T211209Z-1-001.zip` - historical archive; inspect contents before public sharing.
- `drive-download-20261012T211257Z-1-001.zip` - historical archive; inspect contents before public sharing.

## Review notes
- Python files are educational/documentation examples only.
- `legacy_*` files are retained for historical reference and may contain malformed or unverified material.
- This index does not certify the scientific validity or privacy status of every nested file.