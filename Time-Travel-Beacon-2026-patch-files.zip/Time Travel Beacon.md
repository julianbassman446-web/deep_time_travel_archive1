# Time Travel Beacon

This is a speculative research and preservation archive, not a working time-travel system. Begin with [README.md](README.md) and [SCIENTIFIC_CORRECTIONS_AND_LIMITATIONS.md](SCIENTIFIC_CORRECTIONS_AND_LIMITATIONS.md). The current hypothetical mission target is documented in [OCT_16_2026_01-00_AM_EDT_MISSION.md](OCT_16_2026_01-00_AM_EDT_MISSION.md).
