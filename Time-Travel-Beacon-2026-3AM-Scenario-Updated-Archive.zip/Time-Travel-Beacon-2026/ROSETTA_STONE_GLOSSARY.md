# Rosetta Stone: Reader's Guide and Glossary

This guide is a shared vocabulary for interpreting Time-Travel Beacon 2026. It is a documentation aid, not a technical receiver or a message channel through time.

## Evidence labels

- **Established result:** supported by repeatable observation and a strong body of evidence.
- **Mathematical model:** a formal description whose conclusions depend on stated assumptions; a model alone does not show that nature realizes it.
- **Hypothesis:** a proposed explanation or possibility that needs appropriate testing or analysis.
- **Speculative scenario:** an imagined future capability or sequence of events, included for exploration rather than as a factual report.
- **Personal motivation:** the reason the project matters to its author; it is important context but is not evidence for a scientific claim.
- **Software example:** code that performs the operations actually described in its documentation. A program that runs successfully does not prove a physical mechanism exists.

## Key terms

- **Time dilation:** differences in elapsed time associated with relative motion or gravitational conditions; experimentally established.
- **Wormhole:** a hypothetical spacetime connection; a traversable, stable wormhole has not been demonstrated.
- **Warp-bubble metric:** a theoretical spacetime construction, not an operational propulsion system.
- **Closed timelike curve (CTC):** a path that returns to an earlier event in some mathematical spacetime models; physical realizability is unknown.
- **Quantum teleportation:** a quantum-information protocol that uses entanglement and classical communication; it does not teleport a person or provide a demonstrated channel to the past.
- **Temporal information transfer:** a proposed ability to send usable information to an earlier time; no verified practical method is known.
- **Future-robot scenario:** a fictional or hypothetical element in this project's long-range thought experiment; it is not evidence of existing future agents or contact.
- **Rosetta Stone (metaphor):** a clear glossary and mapping between project-specific terms and established scientific language.

## How to evaluate a claim

For each claim, ask: What exactly is asserted? What source or derivation supports it? What assumptions are required? Are the units consistent? Is the result independently reproducible? What evidence would count against it? Is it a simulation, a theoretical result, or a physical observation?

When evidence is missing, label the claim as an open question or speculative scenario rather than presenting it as established fact.
