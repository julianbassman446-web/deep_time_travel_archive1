# Research Priorities and GIS Handoff Condition

This short document summarizes the request in `FUTURE_RESEARCH_DIRECTIVE.md`.

## Requested priorities

- Review every included document and track claims, sources, assumptions, units, uncertainties, and tests.
- Examine how energy might be accounted for and what real constraints apply to any proposed energy source or storage system.
- Assess macroengineering concepts through staged, independently reviewed feasibility work.
- Verify equations and spacetime models; distinguish mathematical consistency from physical feasibility and demonstrated engineering.
- Investigate faster-than-light proposals while acknowledging that established relativity does not allow a massive object to locally reach or exceed light speed, and no practical FTL propulsion or communication system has been demonstrated.
- Evaluate backward-time travel, temporal information transfer, causality, stability, and safety without assuming success.
- Continue credible, safe inquiry over time, documenting failures as well as successes.

## Requested GIS condition

If any defined component is independently demonstrated to work, the project asks researchers to review whether that result justifies a further investigation of transmitting or handing off the Temporal GIS. A result must be described precisely; a simulation or successful code run is not proof of temporal transfer.

There is no known working way to send the GIS or any file into the past or directly reach people or robots in 20,005 AD. No automatic transmission is scheduled. Until a real, independently verified and safe mechanism exists, preserve and publish the archive through ordinary channels.

## Evidence standard

Any claimed breakthrough should include a precise claim, equations and assumptions, reproducible methods, evidence and uncertainty analysis, independent review, and a statement of limitations. The historical record—including COVID-19 history—should be preserved even while the project explores ways to reduce future harm.
