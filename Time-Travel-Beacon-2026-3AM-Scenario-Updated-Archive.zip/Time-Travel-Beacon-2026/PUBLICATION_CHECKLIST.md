# Publication Checklist

Use this checklist after extracting the candidate ZIP.

- [ ] Read the README, scientist invitation, and Rosetta Stone glossary; confirm the project's purpose and scientific limits are represented accurately.
- [ ] Confirm the future-robot/20,005 AD material is clearly labeled hypothetical and does not imply actual future contact.
- [ ] Confirm the COVID-19 section describes a motivation to reduce harm through evidence-based research, not a demonstrated way to change the past.
- [ ] Confirm the scenario timestamp is consistently October 16, 2026, at 3:00 AM EDT / 07:00 UTC.
- [ ] Confirm the phone/Bluetooth section states clearly that ordinary Bluetooth does not enable time travel or transport.
- [ ] Confirm the 3:00 AM scan/transport scenario is labeled hypothetical and is not treated as a real medical or physical procedure.
- [ ] Keep the original complete archive as a private backup; do not upload unreviewed screenshots, PDFs, nested ZIPs, or legacy files.
- [ ] Copy the included files into the corresponding paths in the local Git repository.
- [ ] Inspect the GitHub Desktop change list and verify no unrelated files are being deleted or replaced.
- [ ] Run the two example scripts only as ordinary software examples; check that JSON parses and Python syntax compiles.
- [ ] Commit and push the changes.
- [ ] Open the GitHub repository in a browser and verify the correct files are online.
- [ ] Only then decide whether to archive the GitHub repository.

**Important:** Creating this ZIP does not upload or commit anything to GitHub. GitHub repository archiving is a separate final action and makes the repository read-only.
