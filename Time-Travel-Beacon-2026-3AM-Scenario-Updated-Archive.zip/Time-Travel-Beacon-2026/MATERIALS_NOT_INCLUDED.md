# Materials Not Included in This Public-Review Candidate

The source archive contained screenshots, PDFs, nested ZIP archives, and legacy files with malformed code/JSON or statements that could be mistaken for operational instructions or demonstrated technology. The complete contents of those materials have not all been audited for privacy, provenance, accuracy, or embedded personal information.

For that reason, this candidate intentionally does **not** include those items. This is a precaution, not a claim that the excluded files are harmful or that they have been fully reviewed. Keep the original downloaded archive privately. Before publishing any excluded item, inspect the file itself and all nested contents for names, addresses, medical or private records, credentials, metadata, and unsupported claims.

The excluded source materials include the original `IMG_*.png` screenshots, PDF documents, nested ZIP archives, malformed legacy code/notes, the legacy invalid JSON schema, and the original archive-entrypoint note.
