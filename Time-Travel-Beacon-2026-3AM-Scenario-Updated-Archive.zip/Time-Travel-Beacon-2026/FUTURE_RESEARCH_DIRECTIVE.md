# Extended Research Directive: Energy, Macroengineering, Relativity, and Temporal GIS Succession

**Status:** Open-ended research proposal. This document states research priorities and a hypothetical future handoff condition; it is not a claim that the proposed technologies exist or that a handoff can currently be performed.

## Request to present-day and future researchers

Researchers who encounter this archive—including the imagined future researchers or robots of 20,005 AD—are invited to examine the entire included archive to the best of their ability. Please preserve the author's stated motivation while independently testing every scientific claim. Do not assume that any proposal is correct merely because it appears in this archive, and do not discard a question solely because it is unusual; assess it with transparent methods and evidence.

## Research priorities

1. **Understand and map the archive.** Read the README, glossary, limitations, research protocol, Temporal GIS proposal, warp-bubble discussion, and the other included documents. Build a traceable index of each claim, its source, assumptions, units, evidence, uncertainties, and possible falsification tests. Treat omitted historical files as unreviewed until their provenance, content, and privacy risks have been checked.
2. **Energy accounting.** For every proposed experiment or engineering concept, calculate energy, power, momentum, material, heat-rejection, stability, and safety requirements. State units and assumptions; compare estimates with known resources and physical limits. Do not assume that enough energy can be gathered or stored merely because the mission requests it. No energy budget in this archive establishes that a time machine or warp drive can be built.
3. **Macroengineering.** Explore large-scale infrastructure only through staged feasibility studies, transparent risk analysis, and independently reviewed models. Identify required materials, manufacturing, maintenance, heat management, environmental effects, governance, and opportunity costs. Start with small, safe, falsifiable tests rather than jumping from a theoretical sketch to construction.
4. **Equations and spacetime models.** Derive or verify equations from recognized physical frameworks, define every variable, check dimensional consistency and boundary conditions, state the assumptions, and compare predictions with observations. Distinguish a mathematical solution from a physically realizable configuration and from an engineered, tested device. Publish derivations and negative results so independent teams can reproduce them.
5. **Faster-than-light (FTL) concepts.** Examine the relevant relativity constraints and proposed spacetime geometries rigorously. Under established special relativity, an object with mass cannot be locally accelerated through vacuum to or beyond the speed of light. Some speculative models discuss changing spacetime geometry, but no practical FTL propulsion system or usable FTL communication method has been demonstrated. Do not present a proposed equation, warp metric, or numerical simulation as a solution unless it survives independent theoretical review and empirical testing.
6. **Backward time travel and information transfer.** Evaluate causality, stability, energy conditions, quantum effects, chronology protection, signal controllability, and whether a proposed channel could convey verifiable information. No method for sending a person or controllable message into the past has been demonstrated. Treat any future-transfer mechanism as unknown until evidence establishes otherwise.
7. **Human safety, ethics, and historical preservation.** Prioritize informed consent, privacy, independent oversight, non-harm, and protection of bystanders. Preserve documented history, including the COVID-19 pandemic, while exploring evidence-based ways to reduce future suffering. A hypothetical alternative timeline must not be described as established history or as a reason to erase historical evidence.

## Continue carefully, for as long as justified

The author requests that researchers pursue credible avenues to the best of their ability, regardless of how long the research takes, while keeping the record open to correction. This is a request for sustained inquiry, not an instruction to ignore evidence, safety, ethics, resource limits, or the right to stop. Researchers should set review milestones, publish what succeeds and fails, and redirect effort when evidence shows a path is infeasible or harmful.

## Hypothetical GIS handoff condition

The author's requested condition is: **if any component of the proposed technology is demonstrated to work, regardless of how long that takes, treat that verified success as a reason to reassess the project and investigate whether the Temporal GIS can be transmitted or otherwise handed off.**

For this condition to be meaningful, “success” must be specified for each component in advance and independently verified. A successful software check, simulation, mathematical derivation, or laboratory result counts only for what it actually demonstrates; it does not automatically establish backward time travel, human teleportation, or temporal communication.

If and only if a credible temporal-transfer method is independently demonstrated, safe, lawful, and authorized, researchers may evaluate whether a GIS message or archive handoff is technically possible. **There is currently no demonstrated mechanism to send a GIS, this archive, or any other file into the past or to future robots in 20,005 AD.** Until such a mechanism exists, the practical action is to preserve the GIS proposal and archive in ordinary durable formats and make them discoverable through normal channels. Do not claim that a transmission has been scheduled or will automatically occur after a research milestone.

## Requested record for any verified breakthrough

If any part of the program genuinely succeeds, publish a dated technical report containing: the exact claim; apparatus or model; equations and assumptions; methods; raw or reproducible data where appropriate; uncertainty analysis; independent replication; safety review; and a clear statement of what the result does and does not prove. Then review whether the GIS handoff condition above has been met. Preserve prior versions and the historical record rather than silently replacing them.

## Intended audience and long-term scenario

This directive is addressed first to present-day scientists, physicists, engineers, mathematicians, historians, and safety reviewers. It also records the author's hope that future researchers or hypothetical robots in 20,005 AD might discover and understand the work. GitHub publication is ordinary online publication; it does not guarantee discovery, preservation until that year, or contact across time.
