# File Index — Public Review Candidate

This index lists the files included in this ZIP. It does not claim that the excluded legacy material has been fully reviewed.

## Main documentation

- `README.md` — project summary, scientific status, and next steps.
- `ARCHIVE_OVERVIEW.md` — background and preservation principles.
- `OCT_16_2026_03-00_AM_EDT_MISSION.md` — current hypothetical timestamp and review objectives.
- `SCIENTIFIC_CORRECTIONS_AND_LIMITATIONS.md` — distinguishes established science from hypotheses.
- `ISS_Temporal_Research_Protocol.md` — proposed research review stages.
- `ANONYMOUS_Temporal_GIS_Proposal_for_Backward_Time_Travel_Safety.md` — hypothetical safety/governance proposal.
- `WARP_BUBBLE_HUMAN_TRANSPORT_AND_PHYSICS_CONSTRAINTS.md` — speculative physics discussion.
- `FUTURE_RESEARCH_DIRECTIVE.md` — sustained research request covering energy accounting, macroengineering, equations, FTL constraints, backward-time-transfer limits, safety, and the hypothetical GIS handoff condition.
- `SCIENTIST_AND_PHYSICIST_INVITATION.md` — outreach message for present-day researchers, the Rosetta Stone idea, and COVID-19 harm-reduction motivation.
- `ROSETTA_STONE_GLOSSARY.md` — shared vocabulary and evidence labels for readers.
- `REVIEW_AND_CHANGELOG.md` — changes and validation performed for this candidate.
- `MATERIALS_NOT_INCLUDED.md` — categories deliberately withheld pending review.
- `PUBLICATION_CHECKLIST.md` — remaining steps before GitHub archiving.

- `PHONE_NOTES_AND_BLUETOOTH_CONCEPT.md` — phone notes, imagined Bluetooth interface, privacy and technical limitations.
- `OCT_16_2026_03-00_AM_EDT_MISSION.md` — hypothetical 3:00 AM scenario; not an operational transport schedule.

## Software and data examples

- `bootstrap.py` — prints a scenario timestamp; no hardware or network actions.
- `temporal_receiver_simulation.py` — ordinary local input example; not a temporal receiver.
- `temporal_mission_schema.json` — descriptive hypothetical metadata only.

## Not included in this public-review candidate

Original screenshots, PDFs, nested ZIP files, raw/malformed legacy text, and files containing unsupported operational claims are omitted until their contents, provenance, and privacy implications are individually reviewed. They remain in the separately downloaded original archive, which should be kept as a private backup.
