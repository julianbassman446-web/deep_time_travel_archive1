# Archive Overview

Time-Travel Beacon 2026 is a personal research and preservation project. It collects speculative questions about backward time travel, spacetime geometry, temporal information transfer, and the ethics of proposed interventions. It does not claim to contain a working time machine or teleportation system.

## Two aims

- **Personal:** preserve the hope of learning from past mistakes, gaining closure, avoiding preventable harm, and pursuing meaningful goals.
- **Research:** invite careful, independent examination of speculative concepts, known physics, assumptions, and safety questions.

The personal aim is real; the technology remains hypothetical. No current method has been demonstrated for sending a person or a controllable message into their own past.

## Current scenario timestamp

The active scenario is documented as October 16, 2026, at 3:00 AM EDT (07:00 UTC). This is a recordkeeping choice, not evidence that a mission launched or that an event occurred through time. Any older times in original materials should be treated as historical drafts unless explicitly reconciled.

## Scientific outreach and the “Rosetta Stone” idea

The archive includes an invitation for present-day scientists and physicists to review the concepts, an extended directive covering energy accounting, macroengineering, equations, FTL claims, and a hypothetical Temporal GIS handoff condition, and a glossary intended to make project terminology easier to interpret. “Rosetta Stone” is a metaphor for clear documentation, not a future-message decoder. The project also records a hypothetical future-robot scenario, including the imagined year 20,005 AD; no known method lets this archive directly contact future people or robots.

The wish to reduce the harm associated with COVID-19 is documented as a motivation for evidence-based pandemic preparedness and care, not as a demonstrated time-travel intervention. The extended directive asks researchers to examine proposed technologies rigorously and to reassess a possible GIS handoff only after a component is independently verified; it does not claim that transmission through time is currently possible.

## How to read the archive

Start with `README.md` and `SCIENTIFIC_CORRECTIONS_AND_LIMITATIONS.md`. Then read the research protocol, Temporal GIS proposal, warp-bubble constraints, and future research directive. The Python files are harmless educational examples only; the JSON file is descriptive metadata.

## Preservation principles

Preserve original source files privately; document edits; separate measurements from hypotheses and personal hopes; cite scientific sources for factual claims; and respect privacy, consent, and safety. A proposal or simulation is not a validated experiment.

## Scope note

This public-review candidate deliberately omits original images, PDFs, nested ZIP archives, and legacy files pending full content, provenance, and privacy review. The omission is intentional and should not be interpreted as a claim that those materials were checked and cleared.

## Phone notes and hypothetical scan scenario

The archive documents a proposed phone-notes/Bluetooth interface and a 3:00 AM scan/transport scenario as hypothetical concepts only. Ordinary Bluetooth cannot transmit through time or transport a person. The scan/transport timestamp does not schedule or activate a real physical procedure.
